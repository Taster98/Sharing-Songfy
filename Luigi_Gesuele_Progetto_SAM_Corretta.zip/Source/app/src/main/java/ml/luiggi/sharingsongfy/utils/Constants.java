package ml.luiggi.sharingsongfy.utils;

public final class Constants {
    private Constants(){
    }

    public static final String SERVER_LINK = "http://luiggi.altervista.org/song_db.json";
}
